# GitHub Upload Guide

## 📦 Preparing Your Project for GitHub

### Step 1: Clean Up Large Files

Before uploading, remove these large folders (they'll be recreated when others clone):

```bash
# Delete node_modules folders
rmdir /s /q node_modules
rmdir /s /q server\node_modules

# Delete build folders
rmdir /s /q dist
rmdir /s /q server\dist

# Delete database files
del server\dev.db

# Delete zip files
del servicepro-build.zip
```

**OR** just run: `clean-for-github.bat`

### Step 2: Initialize Git Repository

```bash
git init
git add .
git commit -m "Initial commit: ServicePro Management System"
```

### Step 3: Create GitHub Repository

1. Go to: https://github.com/new
2. Repository name: `servicepro-management`
3. Description: `Full-stack business management system with React, Express, and Supabase`
4. Choose: **Public** or **Private**
5. **DO NOT** initialize with README (you already have one)
6. Click **Create repository**

### Step 4: Push to GitHub

```bash
git remote add origin https://github.com/YOUR-USERNAME/servicepro-management.git
git branch -M main
git push -u origin main
```

Replace `YOUR-USERNAME` with your GitHub username.

---

## 📋 What Gets Uploaded

✅ **Included:**
- Source code (`src/`, `server/src/`)
- Configuration files
- Package.json files
- README and documentation
- Prisma schema
- Public assets
- GitHub workflows

❌ **Excluded (via .gitignore):**
- `node_modules/` (both frontend and backend)
- `dist/` and `build/` folders
- `.env` files (sensitive data)
- Database files (`.db`, `.sqlite`)
- Log files
- Temporary files
- Zip archives

---

## 🔐 Security Notes

### Files NOT Uploaded (Protected):
- `.env` - Contains your Supabase password
- `server/.env` - Contains database credentials
- `node_modules/` - Too large, can be reinstalled
- Database files - Contains local data

### Files Uploaded (Safe):
- `.env.example` - Template without sensitive data
- `server/.env.example` - Template for others to use

---

## 👥 For Others Cloning Your Repo

After cloning, they need to:

```bash
# 1. Install frontend dependencies
npm install

# 2. Install backend dependencies
cd server
npm install

# 3. Copy environment files
copy .env.example .env
copy server\.env.example server\.env

# 4. Update .env files with their own credentials

# 5. Setup database
cd server
npx prisma generate
npx prisma db push

# 6. Start servers
npm run dev (in root folder)
cd server && npm run dev (in another terminal)
```

---

## 📊 Repository Size

After cleanup:
- **Before:** ~500MB (with node_modules)
- **After:** ~5-10MB (source code only)

---

## 🚀 Quick Commands

### Clean for GitHub:
```bash
clean-for-github.bat
```

### Initialize and Push:
```bash
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/YOUR-USERNAME/servicepro-management.git
git push -u origin main
```

### Update Repository:
```bash
git add .
git commit -m "Your commit message"
git push
```

---

## 📝 Recommended README Sections

Your README.md should include:
- ✅ Project description
- ✅ Features
- ✅ Tech stack
- ✅ Installation instructions
- ✅ Environment setup
- ✅ Running the project
- ✅ Database setup
- ✅ Deployment guide

---

## 🔗 Useful Links

- [GitHub Docs](https://docs.github.com)
- [Git Basics](https://git-scm.com/book/en/v2/Getting-Started-Git-Basics)
- [.gitignore Templates](https://github.com/github/gitignore)

---

## ⚠️ Important Notes

1. **Never commit `.env` files** - They contain sensitive credentials
2. **Always use `.env.example`** - Provide templates for others
3. **Exclude `node_modules`** - Too large, can be reinstalled
4. **Don't commit database files** - Contains local data
5. **Keep secrets secret** - Use environment variables

---

## 🎯 Final Checklist

Before pushing to GitHub:

- [ ] Deleted `node_modules/` folders
- [ ] Deleted `dist/` folders
- [ ] Deleted database files
- [ ] Created `.env.example` files
- [ ] Updated `.gitignore`
- [ ] Tested `.gitignore` works
- [ ] Removed sensitive data
- [ ] Updated README.md
- [ ] Committed all changes
- [ ] Pushed to GitHub

Done! 🎉
