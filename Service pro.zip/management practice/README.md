# ServicePro Management System

A comprehensive business management system built with React, TypeScript, and modern web technologies.

## 🚀 Live Demo

**[View Live Demo](https://yourusername.github.io/servicepro-management)**

*Replace `yourusername` with your GitHub username after deployment*

## ✨ Features

### 📊 Dashboard
- Real-time business overview
- Key performance indicators
- Quick access to all modules

### 👥 Client Management
- Add, edit, and manage clients
- Track client status and services
- Client communication history

### 👨‍💼 Employee Management
- Employee directory with workload tracking
- Performance metrics and billable hours
- Department and role management

### 🕐 Time Tracking
- Real-time stopwatch functionality
- Billable hours tracking
- Project and client time allocation

### 📅 Appointments
- Schedule and manage meetings
- Multiple meeting types (In-person, Video, Phone)
- Employee assignment and calendar integration

### 👋 Visitor Management
- Check-in/check-out system
- Visitor to client conversion
- Purpose tracking and follow-ups

### 💬 Messages
- Client communication center
- Message status tracking
- Integrated with client profiles

### 📈 Reports & Analytics
- Comprehensive business reports
- Export functionality (CSV, HTML, JSON)
- Revenue and performance analytics

## 🛠️ Technology Stack

- **Frontend**: React 18, TypeScript
- **Styling**: Tailwind CSS, Radix UI
- **State Management**: TanStack Query (React Query)
- **Routing**: React Router DOM
- **Charts**: Recharts
- **Icons**: Lucide React
- **Build Tool**: Vite
- **Deployment**: GitHub Pages

## 🚀 Quick Start

### Prerequisites
- Node.js 18+ 
- npm or yarn

### Installation

1. Clone the repository:
```bash
git clone https://github.com/yourusername/servicepro-management.git
cd servicepro-management
```

2. Install dependencies:
```bash
npm install
```

3. Start development server:
```bash
npm run dev
```

4. Open [http://localhost:8080](http://localhost:8080) in your browser

## 📦 Deployment

### Deploy to GitHub Pages

1. **Fork or clone this repository**

2. **Update configuration** (if needed):
   - Update `homepage` in `package.json`
   - Update `base` path in `vite.config.ts`

3. **Deploy using GitHub Actions** (Automatic):
   - Push to `main` branch
   - GitHub Actions will automatically build and deploy

4. **Manual deployment**:
```bash
npm run build
npm run deploy
```

See [DEPLOYMENT.md](./DEPLOYMENT.md) for detailed deployment instructions.

## 🏗️ Project Structure

```
src/
├── components/          # Reusable UI components
│   ├── ui/             # Base UI components (buttons, inputs, etc.)
│   └── layout/         # Layout components
├── pages/              # Page components
├── hooks/              # Custom React hooks
├── lib/                # Utility functions and data
├── types/              # TypeScript type definitions
└── contexts/           # React contexts
```

## 🎯 Key Features Implemented

### ✅ Complete CRUD Operations
- All modules support Create, Read, Update, Delete operations
- Form validation and error handling
- Loading states and user feedback

### ✅ Data Persistence
- LocalStorage integration for data persistence
- No backend required for demo purposes
- Data survives page refreshes

### ✅ Professional UI/UX
- Responsive design (mobile, tablet, desktop)
- Dark/light theme support
- Smooth animations and transitions
- Professional business interface

### ✅ Real-time Features
- Live timer functionality
- Real-time data updates
- Interactive dashboards

### ✅ Export Capabilities
- Multiple export formats (CSV, HTML, JSON)
- Comprehensive business reports
- Professional report formatting

## 🔧 Available Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run preview` - Preview production build
- `npm run lint` - Run ESLint
- `npm run test` - Run tests
- `npm run deploy` - Deploy to GitHub Pages

## 🌟 Demo Data

The application includes comprehensive demo data to showcase all features:
- Sample clients, employees, and visitors
- Time tracking entries and appointments
- Messages and business analytics
- All functionality is immediately testable

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- Built with [Vite](https://vitejs.dev/)
- UI components from [Radix UI](https://www.radix-ui.com/)
- Styled with [Tailwind CSS](https://tailwindcss.com/)
- Icons by [Lucide](https://lucide.dev/)

---

**Ready to deploy? Follow the [Deployment Guide](./DEPLOYMENT.md) to get your ServicePro Management System live on GitHub Pages!**