import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { useAuth } from '@/contexts/AuthContext';
import { StatCard } from '@/components/ui/stat-card';
import { RecentVisitors } from '@/components/dashboard/RecentVisitors';
import { RedZoneChats } from '@/components/dashboard/RedZoneChats';
import { TaskList } from '@/components/dashboard/TaskList';
import { ClientAssignment } from '@/components/dashboard/ClientAssignment';
import { Users, UserPlus, Clock, MessageSquare, Building2, FileText, AlertTriangle } from 'lucide-react';

function SuperAdminDashboard() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Admin Dashboard</h1>
        <p className="text-muted-foreground">System overview and configuration</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Total Clients"
          value="487"
          icon={<Users className="h-5 w-5" />}
          trend={{ value: 12, isPositive: true }}
        />
        <StatCard
          title="Active Employees"
          value="52"
          icon={<UserPlus className="h-5 w-5" />}
          variant="accent"
        />
        <StatCard
          title="Departments"
          value="8"
          icon={<Building2 className="h-5 w-5" />}
        />
        <StatCard
          title="Services"
          value="32"
          icon={<FileText className="h-5 w-5" />}
        />
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        <TaskList />
        <ClientAssignment />
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <RecentVisitors />
        </div>
        <RedZoneChats />
      </div>
    </div>
  );
}

function ManagerDashboard() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Manager Dashboard</h1>
        <p className="text-muted-foreground">Team oversight and client management</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="My Clients"
          value="24"
          icon={<Users className="h-5 w-5" />}
        />
        <StatCard
          title="Team Members"
          value="8"
          icon={<UserPlus className="h-5 w-5" />}
          variant="accent"
        />
        <StatCard
          title="Billable Hours (Today)"
          value="6.5h"
          icon={<Clock className="h-5 w-5" />}
        />
        <StatCard
          title="Red Zone Chats"
          value="3"
          icon={<AlertTriangle className="h-5 w-5" />}
          variant="danger"
        />
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <ClientAssignment />
        </div>
        <RedZoneChats />
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        <TaskList />
        <RecentVisitors />
      </div>
    </div>
  );
}

function ReceptionistDashboard() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Reception Dashboard</h1>
        <p className="text-muted-foreground">Front desk operations</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Today's Visitors"
          value="12"
          icon={<UserPlus className="h-5 w-5" />}
          variant="accent"
        />
        <StatCard
          title="In Meeting"
          value="3"
          icon={<Users className="h-5 w-5" />}
        />
        <StatCard
          title="Pending Messages"
          value="5"
          icon={<MessageSquare className="h-5 w-5" />}
          variant="warning"
        />
        <StatCard
          title="Conversions Today"
          value="2"
          icon={<FileText className="h-5 w-5" />}
        />
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <RecentVisitors />
        </div>
        <TaskList />
      </div>
    </div>
  );
}

export default function Dashboard() {
  const { user } = useAuth();

  if (!user) return null;

  return (
    <DashboardLayout>
      {user.role === 'super_admin' && <SuperAdminDashboard />}
      {user.role === 'manager' && <ManagerDashboard />}
      {user.role === 'receptionist' && <ReceptionistDashboard />}
    </DashboardLayout>
  );
}
