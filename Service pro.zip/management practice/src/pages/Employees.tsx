import { useState } from 'react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Plus, Search, Mail, Phone, MoreVertical, Users, Clock, Briefcase, Loader2 } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { cn } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';

const initialEmployees = [
  { id: 'emp1', name: 'Ankit Sharma', email: 'ankit@servicepro.com', mobile: '+91 98765 43210', department: 'GST Services', role: 'Senior Associate', status: 'active' as const, clientLoad: 5, maxLoad: 8, billableHours: 145 },
  { id: 'emp2', name: 'Priya Mehta', email: 'priya@servicepro.com', mobile: '+91 87654 32109', department: 'Income Tax', role: 'Manager', status: 'active' as const, clientLoad: 7, maxLoad: 8, billableHours: 162 },
  { id: 'emp3', name: 'Rahul Verma', email: 'rahul@servicepro.com', mobile: '+91 76543 21098', department: 'Audit', role: 'Associate', status: 'active' as const, clientLoad: 3, maxLoad: 8, billableHours: 128 },
  { id: 'emp4', name: 'Kavita Reddy', email: 'kavita@servicepro.com', mobile: '+91 65432 10987', department: 'GST Services', role: 'Associate', status: 'active' as const, clientLoad: 6, maxLoad: 8, billableHours: 136 },
  { id: 'emp5', name: 'Suresh Kumar', email: 'suresh@servicepro.com', mobile: '+91 54321 09876', department: 'Tax Consultation', role: 'Senior Associate', status: 'inactive' as const, clientLoad: 0, maxLoad: 8, billableHours: 0 },
];

const departments = [
  'GST Services',
  'Income Tax',
  'Audit',
  'Tax Consultation',
  'Company Registration',
  'Compliance',
  'Bookkeeping',
];

const roles = [
  'Associate',
  'Senior Associate',
  'Manager',
  'Senior Manager',
  'Partner',
];

interface EmployeeForm {
  name: string;
  email: string;
  mobile: string;
  department: string;
  role: string;
  status: 'active' | 'inactive';
  maxLoad: number;
}

export default function Employees() {
  const [searchTerm, setSearchTerm] = useState('');
  const [employees, setEmployees] = useState(initialEmployees);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const [employeeForm, setEmployeeForm] = useState<EmployeeForm>({
    name: '',
    email: '',
    mobile: '',
    department: '',
    role: '',
    status: 'active',
    maxLoad: 8,
  });

  const filteredEmployees = employees.filter(employee =>
    employee.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    employee.department.toLowerCase().includes(searchTerm.toLowerCase()) ||
    employee.role.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const resetForm = () => {
    setEmployeeForm({
      name: '',
      email: '',
      mobile: '',
      department: '',
      role: '',
      status: 'active',
      maxLoad: 8,
    });
  };

  const handleAddEmployee = async () => {
    // Validation
    if (!employeeForm.name.trim()) {
      toast({
        title: "Error",
        description: "Employee name is required",
        variant: "destructive",
      });
      return;
    }
    
    if (!employeeForm.email.trim() || !employeeForm.email.includes('@')) {
      toast({
        title: "Error",
        description: "Valid email is required",
        variant: "destructive",
      });
      return;
    }
    
    if (!employeeForm.mobile.trim()) {
      toast({
        title: "Error",
        description: "Mobile number is required",
        variant: "destructive",
      });
      return;
    }

    if (!employeeForm.department || !employeeForm.role) {
      toast({
        title: "Error",
        description: "Department and role are required",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);

    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 1000));

    try {
      // Create new employee
      const newEmployee = {
        id: `emp${Date.now()}`,
        name: employeeForm.name.trim(),
        email: employeeForm.email.trim(),
        mobile: employeeForm.mobile.trim(),
        department: employeeForm.department,
        role: employeeForm.role,
        status: employeeForm.status,
        clientLoad: 0,
        maxLoad: employeeForm.maxLoad,
        billableHours: 0,
      };

      setEmployees([...employees, newEmployee]);
      resetForm();
      setIsAddDialogOpen(false);
      
      toast({
        title: "Success",
        description: "Employee added successfully",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to add employee",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold">Employees</h1>
            <p className="text-muted-foreground">Manage team members and workload</p>
          </div>
          <Button onClick={() => setIsAddDialogOpen(true)}>
            <Plus className="h-4 w-4 mr-2" />
            Add Employee
          </Button>
        </div>

        <div className="flex gap-4">
          <div className="relative flex-1 max-w-sm">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search employees..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredEmployees.map((employee) => (
            <Card key={employee.id} className="animate-fade-in hover:shadow-card-hover transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-4">
                    <Avatar className="h-12 w-12">
                      <AvatarFallback className="bg-primary/10 text-primary font-medium">
                        {employee.name.split(' ').map(n => n[0]).join('')}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <h3 className="font-semibold">{employee.name}</h3>
                      <p className="text-sm text-muted-foreground">{employee.role}</p>
                      <Badge 
                        variant={employee.status === 'active' ? 'secondary' : 'outline'} 
                        className="mt-1 text-xs"
                      >
                        {employee.department}
                      </Badge>
                    </div>
                  </div>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <MoreVertical className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem>
                        <Briefcase className="h-4 w-4 mr-2" />
                        Edit Employee
                      </DropdownMenuItem>
                      <DropdownMenuItem>View Workload</DropdownMenuItem>
                      <DropdownMenuItem>Assign Tasks</DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>

                <div className="mt-4 space-y-2 text-sm">
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Mail className="h-3.5 w-3.5" />
                    {employee.email}
                  </div>
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Phone className="h-3.5 w-3.5" />
                    {employee.mobile}
                  </div>
                </div>

                <div className="mt-4 pt-4 border-t space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-sm">
                      <Users className="h-4 w-4 text-accent" />
                      <span>Client Load</span>
                    </div>
                    <Badge variant={employee.clientLoad >= 7 ? 'destructive' : 'secondary'}>
                      {employee.clientLoad}/{employee.maxLoad}
                    </Badge>
                  </div>
                  <div className="h-2 rounded-full bg-muted overflow-hidden">
                    <div
                      className={cn(
                        'h-full rounded-full transition-all',
                        employee.clientLoad >= 7 ? 'bg-destructive' : 'bg-accent'
                      )}
                      style={{ 
                        width: `${Math.round((employee.clientLoad / employee.maxLoad) * 100)}%`
                      }}
                    />
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Clock className="h-4 w-4" />
                      <span>This Month</span>
                    </div>
                    <span className="font-medium">{employee.billableHours}h billed</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
          {filteredEmployees.length === 0 && (
            <div className="col-span-full text-center py-12">
              <Users className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-semibold">No employees found</h3>
              <p className="text-muted-foreground">
                {searchTerm ? 'Try adjusting your search terms' : 'Add your first employee to get started'}
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Add Employee Dialog */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Add New Employee</DialogTitle>
            <DialogDescription>
              Add a new team member to your organization.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="name">Full Name</Label>
              <Input
                id="name"
                placeholder="Enter employee name"
                value={employeeForm.name}
                onChange={(e) => setEmployeeForm({ ...employeeForm, name: e.target.value })}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                placeholder="Enter email address"
                value={employeeForm.email}
                onChange={(e) => setEmployeeForm({ ...employeeForm, email: e.target.value })}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="mobile">Mobile Number</Label>
              <Input
                id="mobile"
                placeholder="Enter mobile number"
                value={employeeForm.mobile}
                onChange={(e) => setEmployeeForm({ ...employeeForm, mobile: e.target.value })}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="department">Department</Label>
              <Select
                value={employeeForm.department}
                onValueChange={(value) => setEmployeeForm({ ...employeeForm, department: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select department" />
                </SelectTrigger>
                <SelectContent>
                  {departments.map((dept) => (
                    <SelectItem key={dept} value={dept}>
                      {dept}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="role">Role</Label>
              <Select
                value={employeeForm.role}
                onValueChange={(value) => setEmployeeForm({ ...employeeForm, role: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select role" />
                </SelectTrigger>
                <SelectContent>
                  {roles.map((role) => (
                    <SelectItem key={role} value={role}>
                      {role}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="status">Status</Label>
              <Select
                value={employeeForm.status}
                onValueChange={(value: 'active' | 'inactive') => setEmployeeForm({ ...employeeForm, status: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="inactive">Inactive</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="maxLoad">Maximum Client Load</Label>
              <Input
                id="maxLoad"
                type="number"
                min="1"
                max="20"
                placeholder="Enter max client load"
                value={employeeForm.maxLoad}
                onChange={(e) => setEmployeeForm({ ...employeeForm, maxLoad: parseInt(e.target.value) || 8 })}
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                resetForm();
                setIsAddDialogOpen(false);
              }}
              disabled={isLoading}
            >
              Cancel
            </Button>
            <Button onClick={handleAddEmployee} disabled={isLoading}>
              {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Add Employee
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </DashboardLayout>
  );
}