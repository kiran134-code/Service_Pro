import { useState } from 'react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';
import { Plus, Search, Building2, Briefcase, Users, FileText, Edit, Trash2 } from 'lucide-react';

const departments = [
  {
    id: '1',
    name: 'GST Services',
    description: 'All GST related filings and compliance',
    services: [
      { id: '1', name: 'GST Registration', documents: ['PAN Card', 'Aadhar Card', 'Business Proof', 'Bank Statement'], employees: 3 },
      { id: '2', name: 'GST Filing', documents: ['Sales Invoices', 'Purchase Invoices', 'Bank Statement'], employees: 5 },
      { id: '3', name: 'GST Audit', documents: ['Financial Statements', 'GST Returns', 'Reconciliation'], employees: 2 },
    ],
    totalEmployees: 10,
    activeClients: 156,
  },
  {
    id: '2',
    name: 'Income Tax',
    description: 'Income tax filing and planning services',
    services: [
      { id: '4', name: 'ITR Filing', documents: ['Form 16', 'Bank Statement', 'Investment Proofs'], employees: 6 },
      { id: '5', name: 'Tax Planning', documents: ['Income Details', 'Investment Portfolio'], employees: 3 },
      { id: '6', name: 'Tax Audit', documents: ['Financial Statements', 'Audit Report'], employees: 2 },
    ],
    totalEmployees: 11,
    activeClients: 243,
  },
  {
    id: '3',
    name: 'Company Registration',
    description: 'Business incorporation and compliance',
    services: [
      { id: '7', name: 'Private Limited Registration', documents: ['Director KYC', 'Address Proof', 'MOA/AOA'], employees: 4 },
      { id: '8', name: 'LLP Registration', documents: ['Partner KYC', 'Address Proof', 'LLP Agreement'], employees: 3 },
    ],
    totalEmployees: 7,
    activeClients: 45,
  },
  {
    id: '4',
    name: 'Audit Services',
    description: 'Statutory and internal audit services',
    services: [
      { id: '9', name: 'Statutory Audit', documents: ['Financial Statements', 'Vouchers', 'Bank Statements'], employees: 5 },
      { id: '10', name: 'Internal Audit', documents: ['Process Documents', 'Control Framework'], employees: 3 },
    ],
    totalEmployees: 8,
    activeClients: 78,
  },
];

export default function Departments() {
  const [searchTerm, setSearchTerm] = useState('');
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  const filteredDepartments = departments.filter(dept =>
    dept.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold">Departments & Services</h1>
            <p className="text-muted-foreground">Configure organizational structure</p>
          </div>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Add Department
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create New Department</DialogTitle>
                <DialogDescription>
                  Add a new department to your organization
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Department Name</Label>
                  <Input id="name" placeholder="e.g., Tax Consultation" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="description">Description</Label>
                  <Textarea id="description" placeholder="Brief description of the department" />
                </div>
              </div>
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setIsDialogOpen(false)}>Cancel</Button>
                <Button onClick={() => setIsDialogOpen(false)}>Create Department</Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        <div className="flex gap-4">
          <div className="relative flex-1 max-w-sm">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search departments..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        <div className="grid gap-6">
          {filteredDepartments.map((department) => (
            <Card key={department.id} className="animate-fade-in">
              <CardHeader className="pb-4">
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-4">
                    <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center">
                      <Building2 className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <CardTitle className="text-xl">{department.name}</CardTitle>
                      <p className="text-sm text-muted-foreground mt-1">{department.description}</p>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button variant="ghost" size="icon">
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="icon" className="text-destructive">
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                <div className="flex gap-4 mt-4">
                  <div className="flex items-center gap-2">
                    <Users className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">{department.totalEmployees} employees</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Briefcase className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">{department.services.length} services</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <FileText className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">{department.activeClients} active clients</span>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <Accordion type="single" collapsible className="w-full">
                  <AccordionItem value="services" className="border-0">
                    <AccordionTrigger className="text-sm font-medium py-2 hover:no-underline">
                      View Services ({department.services.length})
                    </AccordionTrigger>
                    <AccordionContent>
                      <div className="space-y-3 pt-2">
                        {department.services.map((service) => (
                          <div
                            key={service.id}
                            className="p-4 rounded-lg border bg-muted/30"
                          >
                            <div className="flex items-center justify-between mb-2">
                              <h4 className="font-medium">{service.name}</h4>
                              <Badge variant="secondary">{service.employees} assigned</Badge>
                            </div>
                            <div className="flex flex-wrap gap-1">
                              {service.documents.map((doc) => (
                                <Badge key={doc} variant="outline" className="text-xs">
                                  {doc}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        ))}
                        <Button variant="outline" size="sm" className="w-full">
                          <Plus className="h-3 w-3 mr-1" />
                          Add Service
                        </Button>
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                </Accordion>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </DashboardLayout>
  );
}
