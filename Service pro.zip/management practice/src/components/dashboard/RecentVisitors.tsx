import { useNavigate } from 'react-router-dom';
import { Clock, User, ArrowRight } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

const visitors = [
  { id: '1', name: 'Rajesh Kumar', mobile: '+91 98765 43210', purpose: 'GST Filing Inquiry', time: '10:30 AM', status: 'waiting' as const },
  { id: '2', name: 'Priya Sharma', mobile: '+91 87654 32109', purpose: 'Tax Consultation', time: '11:15 AM', status: 'in-meeting' as const },
  { id: '3', name: 'Amit Patel', mobile: '+91 76543 21098', purpose: 'Company Registration', time: '11:45 AM', status: 'waiting' as const },
  { id: '4', name: 'Sunita Verma', mobile: '+91 65432 10987', purpose: 'ITR Filing', time: '12:00 PM', status: 'completed' as const },
];

const statusStyles = {
  waiting: 'bg-warning/10 text-warning border-warning/20',
  'in-meeting': 'bg-accent/10 text-accent border-accent/20',
  completed: 'bg-success/10 text-success border-success/20',
  converted: 'bg-primary/10 text-primary border-primary/20',
};

export function RecentVisitors() {
  const navigate = useNavigate();

  const handleViewAll = () => {
    navigate('/visitors');
  };

  return (
    <div className="bg-card rounded-xl border shadow-card animate-slide-up">
      <div className="p-6 border-b flex items-center justify-between">
        <div>
          <h3 className="font-semibold text-lg">Today's Visitors</h3>
          <p className="text-sm text-muted-foreground">Front desk activity</p>
        </div>
        <Button 
          variant="ghost" 
          size="sm" 
          className="gap-1"
          onClick={handleViewAll}
        >
          View All <ArrowRight className="h-4 w-4" />
        </Button>
      </div>
      <div className="divide-y">
        {visitors.map((visitor) => (
          <div key={visitor.id} className="p-4 hover:bg-muted/50 transition-colors">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <User className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="font-medium">{visitor.name}</p>
                  <p className="text-sm text-muted-foreground">{visitor.purpose}</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="text-right hidden sm:block">
                  <div className="flex items-center gap-1 text-sm text-muted-foreground">
                    <Clock className="h-3 w-3" />
                    {visitor.time}
                  </div>
                </div>
                <Badge className={cn('capitalize', statusStyles[visitor.status])}>
                  {visitor.status.replace('-', ' ')}
                </Badge>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
