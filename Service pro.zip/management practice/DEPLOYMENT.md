# ServicePro Management - GitHub Pages Deployment Guide

This guide will help you deploy the ServicePro Management System to GitHub Pages so others can access it online.

## Prerequisites

1. A GitHub account
2. Git installed on your computer
3. Node.js and npm installed

## Step-by-Step Deployment

### 1. Create a GitHub Repository

1. Go to [GitHub](https://github.com) and sign in
2. Click the "+" icon in the top right corner
3. Select "New repository"
4. Name your repository `servicepro-management` (or any name you prefer)
5. Make sure it's set to **Public** (required for free GitHub Pages)
6. Click "Create repository"

### 2. Update Configuration (if you used a different repository name)

If you named your repository something other than `servicepro-management`, update these files:

**package.json:**
```json
"homepage": "https://yourusername.github.io/your-repo-name"
```

**vite.config.ts:**
```typescript
base: process.env.NODE_ENV === 'production' ? '/your-repo-name/' : '/',
```

Replace `yourusername` with your GitHub username and `your-repo-name` with your repository name.

### 3. Initialize Git and Push to GitHub

Open terminal/command prompt in your project folder and run:

```bash
# Initialize git repository
git init

# Add all files
git add .

# Commit files
git commit -m "Initial commit: ServicePro Management System"

# Add your GitHub repository as origin
git remote add origin https://github.com/yourusername/servicepro-management.git

# Push to GitHub
git push -u origin main
```

Replace `yourusername` with your actual GitHub username.

### 4. Enable GitHub Pages

1. Go to your repository on GitHub
2. Click on "Settings" tab
3. Scroll down to "Pages" in the left sidebar
4. Under "Source", select "GitHub Actions"
5. The deployment will start automatically

### 5. Manual Deployment (Alternative)

If you prefer manual deployment, you can also use:

```bash
# Install gh-pages package
npm install --save-dev gh-pages

# Build and deploy
npm run deploy
```

## Access Your Deployed Site

After deployment (usually takes 2-5 minutes), your site will be available at:
```
https://yourusername.github.io/servicepro-management
```

## Features Available in Deployed Version

✅ **Fully Functional Business Management System**
- Client Management (Add, Edit, View clients)
- Employee Management (Add, Edit, View employees)
- Visitor Management (Check-in/out, Convert to clients)
- Time Tracking (Start/stop timer, Track billable hours)
- Appointments (Schedule, Manage meetings)
- Messages (Client communication)
- Reports (Export as CSV, HTML, JSON)
- Dashboard (Overview and analytics)

✅ **Data Persistence**
- All data is stored in browser localStorage
- Data persists across sessions
- No backend required

✅ **Professional UI/UX**
- Responsive design (works on mobile/tablet/desktop)
- Dark/Light theme support
- Professional business interface
- Loading states and error handling

## Updating Your Deployed Site

To update your deployed site with new changes:

1. Make your changes locally
2. Commit and push to GitHub:
   ```bash
   git add .
   git commit -m "Update: description of changes"
   git push
   ```
3. GitHub Actions will automatically rebuild and deploy

## Troubleshooting

**Site not loading?**
- Check that your repository is public
- Verify the homepage URL in package.json matches your repository
- Wait a few minutes for deployment to complete

**Build failing?**
- Check the Actions tab in your GitHub repository for error details
- Ensure all dependencies are properly listed in package.json

**Need help?**
- Check the GitHub Actions logs in your repository
- Ensure your repository name matches the configuration

## Demo Credentials

The deployed system includes demo data and doesn't require authentication for demonstration purposes. In a production environment, you would integrate with a proper authentication system.

---

**Your ServicePro Management System is now live and accessible to anyone with the URL!**