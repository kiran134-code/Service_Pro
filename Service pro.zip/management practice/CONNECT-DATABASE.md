# Complete Database Connection Guide

## Current Status
✅ Everything is already configured! You just need to run the commands.

## What's Already Done
- ✅ Frontend configured to use API
- ✅ Backend configured for MySQL
- ✅ Database schema ready
- ✅ All connection files created

## Step-by-Step Connection Process

### Step 1: Find Your MySQL Password

Your MySQL password is what you set during MySQL installation.

**Common scenarios:**
- If you just installed MySQL: Use the password you created
- If you don't remember: You may need to reset it
- If no password was set: Leave it empty

### Step 2: Update Connection String

1. Open the file: `server/.env`
2. Find this line:
   ```
   DATABASE_URL="mysql://root:password@localhost:3306/servicepro"
   ```
3. Replace `password` with your actual MySQL password

**Examples:**

If your password is `admin123`:
```
DATABASE_URL="mysql://root:admin123@localhost:3306/servicepro"
```

If you have no password:
```
DATABASE_URL="mysql://root:@localhost:3306/servicepro"
```

If your username is different (e.g., `admin`):
```
DATABASE_URL="mysql://admin:yourpassword@localhost:3306/servicepro"
```

### Step 3: Create Database and Tables

Open Command Prompt in your project folder and run these commands:

```bash
# Navigate to server folder
cd server

# Delete old migrations (if any)
rmdir /s /q prisma\migrations

# Create the database
mysql -u root -p -e "CREATE DATABASE IF NOT EXISTS servicepro;"

# Run migrations to create tables
npx prisma migrate dev --name init

# Generate Prisma client
npx prisma generate
```

**OR** simply double-click: `setup-database.bat`

### Step 4: Start Backend Server

Open Command Prompt in project folder:

```bash
cd server
npm run dev
```

**OR** double-click: `start-backend.bat`

You should see:
```
Server is running at http://localhost:3000
```

### Step 5: Start Frontend (New Terminal)

Open a NEW Command Prompt in project folder:

```bash
npm run dev
```

**OR** double-click: `start-frontend.bat`

You should see:
```
Local: http://localhost:8080
```

### Step 6: Test the Connection

1. Open browser: http://localhost:8080
2. Login (any credentials work in demo mode)
3. Go to "Clients" page
4. Click "Add Client"
5. Fill the form and click "Add Client"
6. ✅ Data is now saved in MySQL!

## Verify Database Connection

### Check if data is in MySQL:

```bash
mysql -u root -p
USE servicepro;
SHOW TABLES;
SELECT * FROM Client;
```

You should see your tables and data!

## Troubleshooting

### Problem: "Access denied for user 'root'"

**Solution:** Wrong password in `server/.env`

1. Test your MySQL password:
   ```bash
   mysql -u root -p
   ```
2. If it works, use that same password in `server/.env`

### Problem: "Can't connect to MySQL server"

**Solution:** MySQL is not running

**Windows:**
1. Open Services (Win + R, type `services.msc`)
2. Find "MySQL80" (or similar)
3. Right-click → Start

**OR** run:
```bash
net start MySQL80
```

### Problem: "Unknown database 'servicepro'"

**Solution:** Database not created

```bash
mysql -u root -p -e "CREATE DATABASE servicepro;"
```

### Problem: "Port 3000 already in use"

**Solution:** Another app is using port 3000

1. Open `server/.env`
2. Change `PORT=3000` to `PORT=3001`
3. Open root `.env`
4. Change `VITE_API_BASE_URL=http://localhost:3001/api`

### Problem: Frontend shows "Network Error"

**Solution:** Backend is not running

1. Make sure backend terminal shows: "Server is running at http://localhost:3000"
2. Test backend: Open http://localhost:3000/health in browser
3. Should show: `{"status":"ok"}`

## Complete Command Reference

### One-Time Setup:
```bash
# 1. Update server/.env with your MySQL password
# 2. Run setup
cd server
mysql -u root -p -e "CREATE DATABASE servicepro;"
npx prisma migrate dev --name init
npx prisma generate
```

### Every Time You Start:
```bash
# Terminal 1 - Backend
cd server
npm run dev

# Terminal 2 - Frontend
npm run dev
```

### Check Database:
```bash
mysql -u root -p
USE servicepro;
SHOW TABLES;
SELECT * FROM Client;
```

## What Happens When You Add Data

1. **Frontend** (http://localhost:8080)
   - User fills form and clicks "Add Client"
   - React sends HTTP POST request to backend

2. **Backend** (http://localhost:3000)
   - Express server receives request
   - Prisma ORM processes the data
   - Data is inserted into MySQL

3. **MySQL Database**
   - Data is permanently stored
   - Can be queried anytime
   - Survives server restarts

## File Structure

```
project/
├── .env                    # Frontend config (VITE_USE_API=true)
├── server/
│   ├── .env               # Backend config (DATABASE_URL)
│   ├── prisma/
│   │   └── schema.prisma  # Database schema
│   └── src/
│       └── index.ts       # Express server
├── setup-database.bat     # Setup script
├── start-backend.bat      # Start backend
└── start-frontend.bat     # Start frontend
```

## Success Checklist

- [ ] MySQL is installed and running
- [ ] Password updated in `server/.env`
- [ ] Database `servicepro` created
- [ ] Migrations run successfully
- [ ] Backend running on port 3000
- [ ] Frontend running on port 8080
- [ ] Can add/view clients in browser
- [ ] Data visible in MySQL

## Next Steps

Once everything is working:
- ✅ All CRUD operations work (Create, Read, Update, Delete)
- ✅ Data persists across server restarts
- ✅ Multiple users can access same data
- ✅ Ready for production deployment

## Quick Start (TL;DR)

```bash
# 1. Edit server/.env with your MySQL password
# 2. Run these:
cd server
mysql -u root -p -e "CREATE DATABASE servicepro;"
npx prisma migrate dev --name init
npx prisma generate
npm run dev

# 3. New terminal:
npm run dev

# 4. Open: http://localhost:8080
```

Done! 🎉
