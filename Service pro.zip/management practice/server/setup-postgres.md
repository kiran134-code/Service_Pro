# PostgreSQL Setup Guide

## Step 1: Update the Database Connection

Edit `server/.env` and update the DATABASE_URL with your PostgreSQL credentials:

```env
DATABASE_URL="postgresql://USERNAME:PASSWORD@localhost:5432/DATABASE_NAME?schema=public"
```

Replace:
- `USERNAME` - Your PostgreSQL username (default: `postgres`)
- `PASSWORD` - Your PostgreSQL password
- `DATABASE_NAME` - Database name (e.g., `servicepro`)

Example:
```env
DATABASE_URL="postgresql://postgres:mypassword@localhost:5432/servicepro?schema=public"
```

## Step 2: Create the Database

Open PostgreSQL command line (psql) or pgAdmin and run:

```sql
CREATE DATABASE servicepro;
```

## Step 3: Run Migrations

In the `server` directory, run:

```bash
cd server
npx prisma migrate dev --name init
```

This will:
- Create all tables in PostgreSQL
- Generate the Prisma client

## Step 4: (Optional) Seed Initial Data

If you want to add sample data, create `server/prisma/seed.ts`:

```typescript
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  // Create sample clients
  await prisma.client.create({
    data: {
      name: 'ABC Enterprises',
      email: 'contact@abc.com',
      phone: '+91 98765 43210',
      company: 'ABC Enterprises',
      address: 'Mumbai, Maharashtra',
      status: 'active',
    },
  });

  console.log('Seed data created!');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
```

Then run:
```bash
npx tsx prisma/seed.ts
```

## Step 5: Start the Backend Server

```bash
npm run dev
```

The server will start on http://localhost:3000

## Step 6: Start the Frontend

In the root directory:

```bash
npm run dev
```

The frontend will connect to the backend API automatically.

## Troubleshooting

### Connection Error
- Check PostgreSQL is running: `pg_isready`
- Verify credentials in `.env`
- Ensure database exists

### Migration Error
- Delete `server/prisma/migrations` folder
- Run `npx prisma migrate dev --name init` again

### Port Already in Use
- Change PORT in `server/.env` to 3001 or another port
- Update `VITE_API_BASE_URL` in root `.env` accordingly
