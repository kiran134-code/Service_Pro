import express from 'express';
import { Prisma } from '@prisma/client';
import { prisma } from '../lib/prisma.js';

const router = express.Router();

// Get all visitors
router.get('/', async (req, res) => {
    try {
        const visitors = await prisma.visitor.findMany({
            orderBy: { createdAt: 'desc' },
        });
        res.json(visitors);
    } catch (error: any) {
        res.status(500).json({ error: error.message });
    }
});

// Create visitor
router.post('/', async (req, res) => {
    try {
        const visitor = await prisma.visitor.create({
            data: req.body,
        });
        res.json(visitor);
    } catch (error: any) {
        res.status(500).json({ error: error.message });
    }
});

// Update visitor
router.patch('/:id', async (req, res) => {
    try {
        const visitor = await prisma.visitor.update({
            where: { id: req.params.id },
            data: req.body,
        });
        res.json(visitor);
    } catch (error: any) {
        res.status(500).json({ error: error.message });
    }
});

// Checkout visitor
router.post('/:id/checkout', async (req, res) => {
    try {
        const visitor = await prisma.visitor.update({
            where: { id: req.params.id },
            data: {
                checkOutTime: new Date(),
                status: 'completed',
            },
        });
        res.json(visitor);
    } catch (error: any) {
        res.status(500).json({ error: error.message });
    }
});

// Convert visitor to client
router.post('/:id/convert', async (req, res) => {
    const visitorId = req.params.id;
    const clientData = req.body;

    try {
        const result = await prisma.$transaction(async (tx: Prisma.TransactionClient) => {
            // Update visitor status
            const visitor = await tx.visitor.update({
                where: { id: visitorId },
                data: {
                    status: 'converted',
                    checkOutTime: new Date(),
                },
            });

            // Create client
            const client = await tx.client.create({
                data: clientData,
            });

            return { visitor, client };
        });

        res.json({ visitor: result.visitor, clientId: result.client.id });
    } catch (error: any) {
        res.status(500).json({ error: error.message });
    }
});

export default router;
