# Setup Without MySQL Command Line

Since MySQL is not in your PATH, follow these steps:

## Method 1: Using MySQL Workbench (Recommended)

### Step 1: Open MySQL Workbench
1. Open MySQL Workbench (should be installed with MySQL)
2. Click on your local connection (usually "Local instance MySQL80")
3. Enter your password: `password12345`

### Step 2: Create Database
1. In the query window, paste this:
   ```sql
   CREATE DATABASE IF NOT EXISTS servicepro;
   ```
2. Click the lightning bolt icon (⚡) to execute
3. You should see: "1 row(s) affected"

### Step 3: Run Setup Script
1. Close MySQL Workbench
2. Double-click: `setup-database-simple.bat`
3. Wait for it to complete

### Step 4: Start Servers
1. Double-click: `start-backend.bat`
2. Double-click: `start-frontend.bat`
3. Open browser: http://localhost:8080

---

## Method 2: Using phpMyAdmin

### Step 1: Open phpMyAdmin
1. Open your browser
2. Go to: http://localhost/phpmyadmin
3. Login with username: `root`, password: `password12345`

### Step 2: Create Database
1. Click "Databases" tab
2. In "Create database" field, type: `servicepro`
3. Click "Create"

### Step 3: Run Setup Script
1. Double-click: `setup-database-simple.bat`
2. Wait for it to complete

### Step 4: Start Servers
1. Double-click: `start-backend.bat`
2. Double-click: `start-frontend.bat`
3. Open browser: http://localhost:8080

---

## Method 3: Add MySQL to PATH (Advanced)

If you want to use MySQL commands:

1. Find MySQL installation folder (usually):
   ```
   C:\Program Files\MySQL\MySQL Server 8.0\bin
   ```

2. Add to PATH:
   - Right-click "This PC" → Properties
   - Advanced system settings
   - Environment Variables
   - Under "System variables", find "Path"
   - Click Edit → New
   - Add: `C:\Program Files\MySQL\MySQL Server 8.0\bin`
   - Click OK on all windows

3. Restart Command Prompt and try again

---

## Method 4: Skip Database Creation (Let Prisma Do It)

Prisma can create the database automatically:

### Step 1: Update Prisma Schema
Open `server/prisma/schema.prisma` and add this at the top:
```prisma
generator client {
  provider = "prisma-client-js"
}

datasource db {
  provider = "mysql"
  url      = env("DATABASE_URL")
  // Add this line:
  shadowDatabaseUrl = env("SHADOW_DATABASE_URL")
}
```

### Step 2: Update .env
Add to `server/.env`:
```
SHADOW_DATABASE_URL="mysql://root:password12345@localhost:3306/servicepro_shadow"
```

### Step 3: Run Setup
```bash
cd server
npx prisma db push
npx prisma generate
```

This will create the database and tables automatically!

---

## Quick Summary

**Easiest Method:**
1. Open MySQL Workbench
2. Run: `CREATE DATABASE servicepro;`
3. Double-click: `setup-database-simple.bat`
4. Double-click: `start-backend.bat`
5. Double-click: `start-frontend.bat`
6. Open: http://localhost:8080

Done! 🎉
