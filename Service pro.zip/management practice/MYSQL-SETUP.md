# MySQL Setup Guide

## Quick Setup (3 Steps)

### Step 1: Update MySQL Password

Edit `server/.env` and replace `password` with your MySQL root password:

```env
DATABASE_URL="mysql://root:YOUR_PASSWORD@localhost:3306/servicepro"
```

**Common MySQL defaults:**
- Username: `root`
- Password: (the one you set during installation, or empty if none)
- Host: `localhost`
- Port: `3306`

**Examples:**
```env
# If you have a password
DATABASE_URL="mysql://root:mypassword@localhost:3306/servicepro"

# If no password (not recommended for production)
DATABASE_URL="mysql://root:@localhost:3306/servicepro"
```

### Step 2: Run Setup Script

Double-click `setup-database.bat`

This will:
- Create the `servicepro` database
- Run migrations to create all tables
- Generate Prisma client

### Step 3: Start the Servers

1. Double-click `start-backend.bat` (keep running)
2. Double-click `start-frontend.bat` (in new window)
3. Open browser: http://localhost:8080

## Manual Setup (Alternative)

If the script doesn't work, run these commands:

```bash
# 1. Create database
mysql -u root -p
CREATE DATABASE servicepro;
exit;

# 2. Run migrations
cd server
npx prisma migrate dev --name init

# 3. Generate client
npx prisma generate

# 4. Start backend
npm run dev
```

## Database Tables Created

The following tables will be created in MySQL:

1. **Client** - Customer information
2. **Employee** - Staff management
3. **Visitor** - Visitor tracking
4. **Message** - Communication system
5. **TimeEntry** - Time tracking

## Verify Setup

### Check MySQL is running:
```bash
mysql --version
```

### Check database exists:
```bash
mysql -u root -p
SHOW DATABASES;
USE servicepro;
SHOW TABLES;
```

### Check backend connection:
Open browser: http://localhost:3000/health

Should return: `{"status":"ok"}`

## Troubleshooting

### Error: "Access denied for user 'root'"
- Wrong password in `server/.env`
- Update DATABASE_URL with correct password

### Error: "Can't connect to MySQL server"
- MySQL service not running
- Start MySQL from Services (Windows) or:
  ```bash
  net start MySQL80
  ```

### Error: "Unknown database 'servicepro'"
- Database not created
- Run: `mysql -u root -p -e "CREATE DATABASE servicepro;"`

### Error: "Port 3306 already in use"
- Another MySQL instance is running
- Or change port in DATABASE_URL to 3307

### Error: "Migration failed"
- Delete `server/prisma/migrations` folder
- Run setup again

## MySQL Workbench (Optional)

For a GUI to manage your database:
1. Download MySQL Workbench (comes with MySQL)
2. Connect to localhost:3306
3. View and manage your data visually

## Connection String Format

```
mysql://USERNAME:PASSWORD@HOST:PORT/DATABASE
```

Examples:
```
mysql://root:password123@localhost:3306/servicepro
mysql://admin:secret@127.0.0.1:3306/servicepro
mysql://user:pass@192.168.1.100:3306/servicepro
```

## Next Steps

Once setup is complete:
- ✅ All data stored in MySQL
- ✅ Data persists across restarts
- ✅ Ready for production use
- ✅ Can be accessed by multiple users

## Quick Commands

```bash
# Check MySQL status
mysql --version

# Create database
mysql -u root -p -e "CREATE DATABASE servicepro;"

# View data
mysql -u root -p servicepro -e "SELECT * FROM Client;"

# Reset database
cd server
npx prisma migrate reset

# Start servers
start-backend.bat
start-frontend.bat
```
