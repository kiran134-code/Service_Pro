# Supabase Setup Guide

## Step 1: Get Your Supabase Connection String

1. Go to: https://app.supabase.com
2. Select your project
3. Click on **Settings** (gear icon) in the left sidebar
4. Click on **Database**
5. Scroll down to **Connection string**
6. Select **URI** tab
7. Copy the connection string (looks like this):
   ```
   postgresql://postgres:[YOUR-PASSWORD]@db.xxxxxxxxxxxxx.supabase.co:5432/postgres
   ```

## Step 2: Update server/.env

Open `server/.env` and replace both connection strings:

```env
DATABASE_URL="postgresql://postgres:[YOUR-PASSWORD]@db.[YOUR-PROJECT-REF].supabase.co:5432/postgres"

DIRECT_URL="postgresql://postgres:[YOUR-PASSWORD]@db.[YOUR-PROJECT-REF].supabase.co:5432/postgres"
```

**Important:** Replace `[YOUR-PASSWORD]` with your actual database password from Supabase!

### Example:
If your connection string from Supabase is:
```
postgresql://postgres:mySecretPass123@db.abcdefghijk.supabase.co:5432/postgres
```

Then your `server/.env` should be:
```env
DATABASE_URL="postgresql://postgres:mySecretPass123@db.abcdefghijk.supabase.co:5432/postgres"

DIRECT_URL="postgresql://postgres:mySecretPass123@db.abcdefghijk.supabase.co:5432/postgres"
```

## Step 3: Run Migrations

Open Command Prompt in your project folder:

```bash
cd server
npx prisma migrate dev --name init
npx prisma generate
```

This will create all tables in your Supabase database!

## Step 4: Start Servers

**Terminal 1 - Backend:**
```bash
cd server
npm run dev
```

**Terminal 2 - Frontend:**
```bash
npm run dev
```

**OR** use the batch files:
- Double-click: `start-backend.bat`
- Double-click: `start-frontend.bat`

## Step 5: Open Browser

Go to: http://localhost:8080

## Verify in Supabase

1. Go to your Supabase project
2. Click **Table Editor** in the left sidebar
3. You should see 5 tables:
   - Client
   - Employee
   - Visitor
   - Message
   - TimeEntry

## Advantages of Supabase

✅ **Cloud-based** - No local server needed
✅ **Always available** - Works from anywhere
✅ **Free tier** - 500MB database, 2GB bandwidth
✅ **Built-in UI** - View/edit data in Supabase dashboard
✅ **Automatic backups** - Data is safe
✅ **Real-time** - Can add real-time features later

## Troubleshooting

### Error: "Can't reach database server"
- Check your internet connection
- Verify the connection string is correct
- Make sure you replaced [YOUR-PASSWORD] with actual password

### Error: "SSL connection required"
Add `?sslmode=require` to the end of your connection string:
```
DATABASE_URL="postgresql://postgres:pass@db.xxx.supabase.co:5432/postgres?sslmode=require"
```

### Error: "Password authentication failed"
- Go to Supabase → Settings → Database
- Click "Reset Database Password"
- Use the new password in your connection string

## Connection String Format

```
postgresql://USER:PASSWORD@HOST:PORT/DATABASE
```

For Supabase:
- USER: `postgres`
- PASSWORD: Your database password
- HOST: `db.[YOUR-PROJECT-REF].supabase.co`
- PORT: `5432`
- DATABASE: `postgres`

## Quick Commands

```bash
# Run migrations
cd server
npx prisma migrate dev --name init

# Generate Prisma client
npx prisma generate

# View database in browser
npx prisma studio

# Reset database (careful!)
npx prisma migrate reset
```

## Next Steps

Once connected:
- ✅ All data stored in cloud
- ✅ Access from anywhere
- ✅ No local database needed
- ✅ View data in Supabase dashboard
- ✅ Ready for production!
